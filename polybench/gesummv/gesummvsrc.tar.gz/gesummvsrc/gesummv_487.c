#include "gesummv.h"

component void gesummv(DATA_TYPE alpha, DATA_TYPE beta, DATA_TYPE A[N][N], DATA_TYPE B[N][N], DATA_TYPE x[N], DATA_TYPE y_out[N])
{
    int i, j;
hls_numbanks(8)
	DATA_TYPE buff_A[N][N];
hls_numbanks(8)
	DATA_TYPE buff_B[N][N];
hls_numbanks(8)
	DATA_TYPE buff_x[N];
hls_numbanks(8)
	DATA_TYPE buff_y_out[N];
hls_numbanks(8)
	DATA_TYPE tmp1[N];
hls_numbanks(8)
	DATA_TYPE tmp2[N];

	lprd_1: for(i = 0; i < N; i++) {
		buff_x[i] = x[i];
		tmp1[i] = 0;
		tmp2[i] = 0;
		buff_y_out[i] = 0;
#pragma unroll 8
 for(j = 0; j < N; j++) {
			buff_A[i][j] = A[i][j];
			buff_B[i][j] = B[i][j];
		}
	}

    lp1: for(i = 0; i < N; i++) {
#pragma unroll 1
 for(j = 0; j < N; j++) {
	        tmp1[i] += alpha * buff_A[i][j] * buff_x[j];
        }
    }

	lp3: for(i = 0; i < N; i++) {
#pragma unroll 4
 for(j = 0; j < N; j++) {
	        tmp2[i] += beta * buff_B[i][j] * buff_x[j];
        }
    }

	lp5: for(i = 0; i < N; i++) {
		buff_y_out[i] = tmp1[i] + tmp2[i];
	}

#pragma unroll 8
 for(i = 0; i < N; i++) {
		y_out[i] = buff_y_out[i];
	}
}
